﻿using Crudop.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace Crudop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        public readonly IConfiguration _configuration;

        public DepartmentController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult Get()
        {
            String Query = @"select DepartmentId,DepartmentName from Department";

            DataTable table= new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader  myreader;
            using(SqlConnection mycon= new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    myreader= mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult(table);

        }
        [HttpPost]
        public JsonResult post(Department Dep)
        {
            String Query = @"insert into Department values(@Departmentname)";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    mycmd.Parameters.AddWithValue("@Departmentname", Dep.DepartmentName);
                    myreader= mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Added Sucessfully");

        }
        [HttpPut]
        public JsonResult put(Department Dep)
        {
            String Query = @"update  Department set DepartmentName=@Departmentname
                            Where DepartmentID=@DepartmentId";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    mycmd.Parameters.AddWithValue("@DepartmentId", Dep.DepartmentId);
                    mycmd.Parameters.AddWithValue("@Departmentname", Dep.DepartmentName);
                    myreader = mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Updated Sucessfully");

        }
        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            String Query = @"Delete from  Department Where DepartmentID=@DepartmentId";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    mycmd.Parameters.AddWithValue("@DepartmentId",id);
                    myreader = mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Deleted Data Sucsessfully");

        }
    }
}
