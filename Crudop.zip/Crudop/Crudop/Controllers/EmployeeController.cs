﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using Crudop.Models;

namespace Crudop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        public readonly IWebHostEnvironment _Env;

        public EmployeeController(IConfiguration configuration, IWebHostEnvironment env)
        {
            _configuration = configuration;
            _Env = env;
        }

        [HttpGet]
        public JsonResult Get()
        {
            String Query = @"select * from Employee";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    myreader = mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult(table);
        }
        [HttpPost]
        public JsonResult post(Employee Emp)
        {
            String Query = @"insert into Employee (EmployeeName,Department,Dataofjoining,PhotofileName) 
                                values (@EmployeeName,@Department,@Dataofjoining,@PhotofileName)";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    mycmd.Parameters.AddWithValue("@EmployeeName", Emp.EmployeeName);
                    mycmd.Parameters.AddWithValue("@Department", Emp.Department);
                    mycmd.Parameters.AddWithValue("@Dataofjoining", Emp.Dataofjoining);
                    mycmd.Parameters.AddWithValue("@PhotofileName", Emp.PhotofileName);
                    myreader = mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Data Added SuccessFully");
        }
        [HttpPut]
        public JsonResult Put(Employee Emp)
        {
            String Query = @"update Employee set EmployeeName=@EmployeeName,Department =@Department,Dataofjoining =@Dataofjoining,PhotofileName =@PhotofileName 
                            Where EmployeeID= @EmployeeID";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    mycmd.Parameters.AddWithValue("@EmployeeID", Emp.EmployeeID);
                    mycmd.Parameters.AddWithValue("@EmployeeName", Emp.EmployeeName);
                    mycmd.Parameters.AddWithValue("@Department", Emp.Department);
                    mycmd.Parameters.AddWithValue("@Dataofjoining", Emp.Dataofjoining);
                    mycmd.Parameters.AddWithValue("@PhotofileName", Emp.PhotofileName);
                    myreader = mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Data Updated SuccessFully");
        }
        [HttpDelete("{id}")]
        public JsonResult Detete(int ID)
        {
            String Query = @"Delete from Employee Where EmployeeID= @EmployeeID";

            DataTable table = new DataTable();
            string sqlDatsource = _configuration.GetConnectionString("EmployeeAppcon");
            SqlDataReader myreader;
            using (SqlConnection mycon = new SqlConnection(sqlDatsource))
            {
                mycon.Open();
                using (SqlCommand mycmd = new SqlCommand(Query, mycon))
                {
                    mycmd.Parameters.AddWithValue("@EmployeeID", ID);
                    myreader = mycmd.ExecuteReader();
                    table.Load(myreader);
                    myreader.Close();
                    mycon.Close();
                }
            }
            return new JsonResult("Data Deleted SuccessFully");
        }

        [Route("SaveFile")]
        [HttpPost]

        public JsonResult SaveFile()
        {
            try
            {
                var httpRequest = HttpContext.Request.Form;
                var postedfile = httpRequest.Files[0];
                string filename = postedfile.FileName;
                var PhysicalPath = _Env.ContentRootPath + "/Photos/" + filename;

                using (var stream = new FileStream(PhysicalPath, FileMode.Create))
                {
                    postedfile.CopyTo(stream);
                }
                return new JsonResult(filename);
            }
            catch (Exception)
            {

                return new JsonResult("img1");
            }
        }



    }
}
