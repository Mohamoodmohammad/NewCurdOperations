﻿namespace Crudop.Models
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }

        public string Dataofjoining { get; set; }

        public String PhotofileName { get; set; }


    }
}
